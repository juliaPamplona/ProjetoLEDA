
# Atualizar diretório da database

Após fazer o dowload em [https://www.kaggle.com/datasets/bhavikjikadara/tweets-dataset?resource=download], atualizar a `String dir` na classe main com o respectivo diretório local que se encontra o arquivo baixado.
